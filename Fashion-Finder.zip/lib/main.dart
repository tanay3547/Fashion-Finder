import 'package:flutter/material.dart';
import 'package:flutterapp/fashion_20finderapp/generatedloggedoutwidget/GeneratedLoggedoutWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedregisterstep1widget/GeneratedRegisterstep1Widget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedunionwidget1/GeneratedUnionWidget1.dart';
import 'package:flutterapp/fashion_20finderapp/generatedregisterstep2widget/GeneratedRegisterStep2Widget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedloginwidget1/GeneratedLoginWidget1.dart';
import 'package:flutterapp/fashion_20finderapp/generatedprofilepagewidget/GeneratedProfilePageWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedprofilepageeditinterestswidget/GeneratedProfilePageEditInterestsWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedrecentorderwidget/GeneratedRecentOrderWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedmarketplace1widget/GeneratedMarketPlace1Widget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedmarketplace2widget/GeneratedMarketPlace2Widget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedpostenhancedwidget/GeneratedPostEnhancedWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedsellpagewidget/GeneratedSellPageWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedprofilewidget/GeneratedProfileWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedlogosocial1widget/GeneratedLogosocial1Widget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedmessagewidget/GeneratedMessageWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedchatwidget/GeneratedChatWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedaddwidget/GeneratedAddWidget.dart';
import 'package:flutterapp/fashion_20finderapp/generatedplusmathwidget1/GeneratedPlusMathWidget1.dart';

void main() {
  runApp(Fashion_20FinderApp());
}

class Fashion_20FinderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedLoggedoutWidget',
      routes: {
        '/GeneratedLoggedoutWidget': (context) => GeneratedLoggedoutWidget(),
        '/GeneratedRegisterstep1Widget': (context) =>
            GeneratedRegisterstep1Widget(),
        '/GeneratedUnionWidget1': (context) => GeneratedUnionWidget1(),
        '/GeneratedRegisterStep2Widget': (context) =>
            GeneratedRegisterStep2Widget(),
        '/GeneratedLoginWidget1': (context) => GeneratedLoginWidget1(),
        '/GeneratedProfilePageWidget': (context) =>
            GeneratedProfilePageWidget(),
        '/GeneratedProfilePageEditInterestsWidget': (context) =>
            GeneratedProfilePageEditInterestsWidget(),
        '/GeneratedRecentOrderWidget': (context) =>
            GeneratedRecentOrderWidget(),
        '/GeneratedMarketPlace1Widget': (context) =>
            GeneratedMarketPlace1Widget(),
        '/GeneratedMarketPlace2Widget': (context) =>
            GeneratedMarketPlace2Widget(),
        '/GeneratedPostEnhancedWidget': (context) =>
            GeneratedPostEnhancedWidget(),
        '/GeneratedSellPageWidget': (context) => GeneratedSellPageWidget(),
        '/GeneratedProfileWidget': (context) => GeneratedProfileWidget(),
        '/GeneratedLogosocial1Widget': (context) =>
            GeneratedLogosocial1Widget(),
        '/GeneratedMessageWidget': (context) => GeneratedMessageWidget(),
        '/GeneratedChatWidget': (context) => GeneratedChatWidget(),
        '/GeneratedAddWidget': (context) => GeneratedAddWidget(),
        '/GeneratedPlusMathWidget1': (context) => GeneratedPlusMathWidget1(),
      },
    );
  }
}
